import React from "react";

export default function Header() {
  const styleObj = {
    height: "100px",
  };

  return (
    <div>
      <div style={styleObj}>Header</div>
    </div>
  );
}
