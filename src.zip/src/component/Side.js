import React from "react";

export default function Side() {
  const side = {
    height: "800px",
    width: "200px",
  };
  return <div style={side}>Side</div>;
}
